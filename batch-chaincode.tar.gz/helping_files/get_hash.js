const crypto = require('crypto');

const testResults_b5 = {
    viscosity: { result: "Passed", details: "40°C: 68.5 cSt, 100°C: 10.1 cSt" },
    metalWear: { result: "Passed", particles: "3 ppm" },
    tbn: { result: "Passed", value: "10.2 mg KOH/g" },
    tan: { result: "Passed", value: "1.2 mg KOH/g" },
    flashPoint: { result: "Passed", value: "230°C" },
    insolubleMatter: { result: "Passed", value: "0.3%" },
    oxidation: { result: "Passed", value: "8%" }
};

const testResultsHash = crypto.createHash('sha256').update(JSON.stringify(testResults_b5)).digest('hex');
console.log(testResultsHash); // Use this hash in your invoke command


